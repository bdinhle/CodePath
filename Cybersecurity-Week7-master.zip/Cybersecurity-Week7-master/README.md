# Cybersecurity-Week7
WordPress vs. Kali
